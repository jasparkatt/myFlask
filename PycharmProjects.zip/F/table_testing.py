
# this is using the alpha_vantage wrapper python package...not quite the same as using the api directly as code below
from alpha_vantage.timeseries import TimeSeries
from alpha_vantage.techindicators import TechIndicators
import pandas as pd
from IPython.display import HTML,display
from alpha_vantage.sectorperformance import SectorPerformances
import requests
import json
from pprint import pprint



# %%
key = 'LAJBI8EN52GC18OY'
ts = TimeSeries(key, output_format='pandas')
# ti = TechIndicators(key)

# pprint(ts)
# pprint(ti)


# %%
aapl_data, aapl_meta_data = ts.get_daily(symbol='GME')
# aapl_sma, aapl_meta_sma = ti.get_sma(symbol='GME')
print(aapl_data)
print('      ---break---      ')

##TESTING DATATABLES WITH PANDAS DF's
# Creates the dataframe
df = pd.DataFrame(aapl_data)

# Parses the dataframe into an HTML element with 3 Bootstrap classes assigned.
html = df.to_html(classes=["table-bordered", "table-striped", "table-hover"])

text_file = open("index.html", "w")
text_file.write(html)
text_file.close()

table = (df.to_html(classes=["table-bordered", "table-striped", "table-hover"]))
text_file = open("index2.html", "w")
text_file.write(table)
text_file.close()

# print(aapl_meta_data)
# print('      ---break---      ')
# pprint(aapl_sma)
# print('      ---break---      ')
# print(aapl_meta_sma)


# %%
# this is using the actual api from alphavantage to get the data from the url api
# just returns a json. You will need to get it into a dataframe perhaps?


# key = 'LAJBI8EN52GC18OY'
# ticker = 'GME'
# url = 'https://www.alphavantage.co/query?function=TIME_SERIES_DAILY_ADJUSTED&symbol={}&apikey={}'.format(ticker, key)
# response = requests.get(url)
# pprint(response.json())

# %%
# messing around with loops to get multi datapoints using alpha_vantage wrapper

# key = 'LAJBI8EN52GC18OY'
# ts = TimeSeries(key, output_format='pandas')
# symbols = ['AAPL', 'GOOG', 'TSLA', 'MSFT', 'GME']
# for symbol in symbols:
#     data = ts.get_daily(symbol)
#     pprint(data)


# %%
# from alpha_vantage.sectorperformance import SectorPerformances
# sp = SectorPerformances(key='LAJBI8EN52GC18OY', output_format='pandas')
# data, meta_data = sp.get_sector()
# data.describe()


