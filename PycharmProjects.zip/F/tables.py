import pandas as pd
from IPython.display import HTML
from alpha_vantage.timeseries import TimeSeries

key = 'LAJBI8EN52GC18OY'
ts = TimeSeries(key, output_format='pandas')

aapl_data = ts.get_daily(symbol='GME')

##TESTING DATATABLES WITH PANDAS DF's
# Creates the dataframe
df = pd.DataFrame(aapl_data)

# result = df.to_html()
# print(result)

html = df.to_html()

# write html to file
text_file = open("index.html", "w")
text_file.write(html)
text_file.close()

#HTML(df.to_html(classes='table table-striped'))
