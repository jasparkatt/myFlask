from flask import Flask, render_template, redirect, url_for, request
from flask_cors import CORS
import os

# create flask class instanceb
app = Flask(__name__)
app.config.from_pyfile('config.cfg', silent=True)
CORS(app)
accessToken = os.getenv('MAPBOX_ACCESS_TOKEN')


# listen for a route at root '/'
# this will be the home page for fishing thing
# need a template/index.html file here to load in render_template func()
@app.route('/')
def index():
    return render_template('indexPage.html')


# route for handling the login page logic
@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        if request.form['username'] != 'admin' or request.form['password'] != 'admin':
            error = 'Invalid Credentials. Please try again.'
        else:
            return redirect(url_for('index'))
    return render_template('login2.html', error=error)


@app.route('/folio')
def folioPage():
    return render_template('folioPage.html')


# route for data entry to postgresql 'fishing' db tables
@app.route('/data')
def dataPage():
    return render_template('dataPage.html')


# route for map with some data displayed
@app.route('/map')
def mapPage():
    print(accessToken)
    return render_template('mapPage.html')
